Fait par moi et deux autres coll�gues 

Langages utilis�s : HTML/CSS, SQL, PHP, Bulma (FrameWork)
Nous avons utilis� uWamp pour faire marcher le PHP et nous avons utilis�
PHPMyAdmin pour la base de donn�e.

C'est un projet consistant en la cr�ation d'un site de location de v�hicule.
Le loueur peut ainsi ajouter des voitures 
Les clients peuvent en louer.


Voici une petite liste d'entreprise deja enregistrer dans notre base de donn�es
Ainsi que l'identifiant du loueur && de l'admin 




Loueur :   identifiant  : admin
		   Mot de passe : admin


Loueur :   identifiant  : loueur
		   Mot de passe : loueur


Clients :  identifiant  : BouBoucars
		   Mot de passe : 1234 


Clients :  identifiant  : Stonks
		   Mot de passe : e1023 


Clients :  identifiant  : ecoMangue
		   Mot de passe : abcd 


Clients :  identifiant  : ecoMangue
		   Mot de passe : abcd


Clients :  identifiant  : TainkCorp
		   Mot de passe : 0000  







