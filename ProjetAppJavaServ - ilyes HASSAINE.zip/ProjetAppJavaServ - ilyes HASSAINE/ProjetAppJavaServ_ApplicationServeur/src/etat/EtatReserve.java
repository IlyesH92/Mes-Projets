package etat;

public class EtatReserve extends AbstractEtat{

	
}
