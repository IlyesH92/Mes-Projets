package Mediatheque;

import client.Abonne;

public class LiaisonEmprunte extends LiaisonAboDoc{

	public LiaisonEmprunte(Abonne a, IDocument d) {
		super(a, d);
	}

	
}
