Par ilyes HASSAINE et 3 collègues

Ce projet consiste à simuler une application de louage de document dans une bibliothèque.

L'application serveur s'occupera de rentrer dans la base de donnée les documents que
le client souhaite louer ou réserver. un client ne peut pas louer ou réserver un document
déjà loué ou réservé.

L'application client sera l'interface que le client utilisera pour louer.

Langage utilisé : JAVA

Notions utilisé : Interface, Héritage, Design Pattern (Statement), Thread, Serveur, polymorphisme
