Fait par ilyes HASSAINE et un collègue

Notre projet consistait à créer une base de donnée ainsi qu’une série de fonctions et de
procédures. L’application concernait une gestion de projet dans un centre de prospection. 
Les prospecteurs adhèrent à des projets, et participent à des séminaire concernant ceux-ci.
L’application possède une fonction et cinq procédures qui nous permettent d’afficher le 
nombre de prospecteurs d’un projet, les adhérents présents lors d’un séminaire, ou bien de
modifier le nombre d’adhérents d’un projet et d’en ajouter.

Langage utilisé : SQL

Notion utilisée : Procédure, Fonction
