A l'occasion d'un projet à faire en première année, 
j'ai eu à créer un site internet ePortFolio
récapitulant mes compétences (avant octobre 2020), 
mes passions etc.

Pour accéder au site : Cliquez sur "Accueil"

Langages utilisés : HTML/CSS

